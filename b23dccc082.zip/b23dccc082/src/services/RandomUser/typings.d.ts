declare module RandomUser {
	export interface Record {
		first: string;
		last: string;
		email: string;
		address: string;
		created: string;
		balance: string;
	}
}
