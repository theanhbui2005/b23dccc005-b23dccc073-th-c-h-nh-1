declare module quanlymonhoc {
	export interface Record {
		code: string;
		subject: string;
		content: string;
		difficulty: string;
		knowledgeBlock: string;
	}
}
