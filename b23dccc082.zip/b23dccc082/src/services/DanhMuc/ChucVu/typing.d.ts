declare module ChucVu {
  export interface IRecord {
    _id: string;
    ma: string;
    ten: string;
    createdAt?: string;
    updatedAt?: string;
  }
}
