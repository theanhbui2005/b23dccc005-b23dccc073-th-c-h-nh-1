import menu from './vi-VN/menu';
import pages from './vi-VN/pages';

export default {
	'app.copyright.produced': 'RIPT',
	...menu,
	...pages,
};
