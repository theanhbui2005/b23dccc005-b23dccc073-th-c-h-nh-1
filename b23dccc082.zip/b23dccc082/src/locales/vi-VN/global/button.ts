export default {
	'global.button.themmoi': 'Thêm mới',
	'global.button.luulai': 'Lưu lại',
	'global.button.huy': 'Hủy',
	'global.button.tieptheo': 'Tiếp theo',
	'global.button.taixuongdulieu': 'Tải xuống dữ liệu',
	'global.button.hoanthanh': 'Hoàn thành',
	'global.button.nhapdulieu': 'Nhập dữ liệu',
	'global.button.xuatdulieu': 'Xuất dữ liệu',
	'global.button.tailai': 'Tải lại',
	'global.button.boloctuychinh': 'Bộ lọc tùy chỉnh',
	'global.button.tongso': 'Tổng số',
};
