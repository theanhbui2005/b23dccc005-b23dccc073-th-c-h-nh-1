import button from './button';
import message from './message';
import title from './title';

export default {
	...button,
	...title,
	...message,
};
