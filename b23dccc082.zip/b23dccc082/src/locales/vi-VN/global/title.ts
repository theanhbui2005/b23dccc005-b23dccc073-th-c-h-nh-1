export default {
	'global.title.themmoi': 'Thêm mới',
	'global.title.chinhsua': 'Chỉnh sửa',
};
